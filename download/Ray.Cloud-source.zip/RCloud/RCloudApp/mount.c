/*
  Dokan : user-mode file system library for Windows

  Copyright (C) 2008 Hiroki Asakawa info@dokan-dev.net

  http://dokan-dev.net/en

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the Free
Software Foundation; either version 3 of the License, or (at your option) any
later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU Lesser General Public License along
with this program. If not, see <http://www.gnu.org/licenses/>.
*/
//-----------------------------------------------------------------------------------------------
#include <windows.h>
#include <stdio.h>
#include "dokani.h"

extern PDOKAN_INSTANCE	g_Instance;

//-----------------------------------------------------------------------------------------------
//--- DokanServiceCheck
//-----------------------------------------------------------------------------------------------
static 
BOOL
DokanServiceCheck(
	LPCWSTR	ServiceName)
{
	SC_HANDLE		controlHandle;
	SC_HANDLE		serviceHandle;

	controlHandle = OpenSCManager(NULL, NULL, SC_MANAGER_CONNECT);

	if (controlHandle == NULL) 
	{
		DBGPRINT("[RCloudApp] DokanServiceCheck() : ...failed to open SCM Error=[%d]", GetLastError());
		
		return FALSE;
	}

	serviceHandle = OpenService(controlHandle, ServiceName, SERVICE_START | SERVICE_STOP | SERVICE_QUERY_STATUS);

	if (serviceHandle == NULL) 
	{
		CloseServiceHandle(controlHandle);
		
		return FALSE;
	}
	
	CloseServiceHandle(serviceHandle);
	CloseServiceHandle(controlHandle);

	return TRUE;
}

//-----------------------------------------------------------------------------------------------
//--- DokanServiceControl
//-----------------------------------------------------------------------------------------------
static 
BOOL
DokanServiceControl(
	LPCWSTR	ServiceName,
	ULONG	Type)
{
	SC_HANDLE		controlHandle;
	SC_HANDLE		serviceHandle;
	SERVICE_STATUS	ss;
	BOOL			result = TRUE;

	controlHandle = OpenSCManager(NULL, NULL, SC_MANAGER_CONNECT);

	if (controlHandle == NULL) 
	{
		DOKANDBGPRINT("[RCloudApp] DokanServiceControl() : ...failed to open SCM Error=[%d]", GetLastError());

		return FALSE;
	}

	serviceHandle = OpenService(controlHandle, ServiceName,	SERVICE_START | SERVICE_STOP | SERVICE_QUERY_STATUS | DELETE);

	if (serviceHandle == NULL) 
	{
		DOKANDBGPRINTW(L"[RCloudApp] DokanServiceControl() : ...failed to open Service=[%s], Error=[%d]", ServiceName, GetLastError());
		CloseServiceHandle(controlHandle);
		
		return FALSE;
	}
	
	QueryServiceStatus(serviceHandle, &ss);

	if (Type == DOKAN_SERVICE_DELETE) 
	{
		if (DeleteService(serviceHandle)) 
		{
			DOKANDBGPRINTW(L"[RCloudApp] DokanServiceControl() : ...ServiceName=[%s] deleted", ServiceName);
			
			result = TRUE;
		} 
		else 
		{
			DOKANDBGPRINTW(L"[RCloudApp] DokanServiceControl() : ...failed to delete serviceName=[%s], Error=[%d]", ServiceName, GetLastError());
			
			result = FALSE;
		}
	} 
	else if (ss.dwCurrentState == SERVICE_STOPPED && Type == DOKAN_SERVICE_START) 
	{
		if (StartService(serviceHandle, 0, NULL)) 
		{
			DOKANDBGPRINTW(L"[RCloudApp] DokanServiceControl() : ...ServiceName=[%s] started", ServiceName);
			
			result = TRUE;
		} 
		else 
		{
			DOKANDBGPRINTW(L"[RCloudApp] DokanServiceControl() : ...failed to start Service ServiceName=[%s], Error=[%d]", ServiceName, GetLastError());
			
			result = FALSE;
		}
	} 
	else if (ss.dwCurrentState == SERVICE_RUNNING && Type == DOKAN_SERVICE_STOP) 
	{
		if (ControlService(serviceHandle, SERVICE_CONTROL_STOP, &ss)) 
		{
			DOKANDBGPRINTW(L"[RCloudApp] DokanServiceControl() : ...ServiceName=[%s] stopped", ServiceName);
			
			result = TRUE;
		} 
		else 
		{
			DOKANDBGPRINTW(L"[RCloudApp] DokanServiceControl() : ...failed to stop service ServiceName=[s], Error=[%d]", ServiceName, GetLastError());
			
			result = FALSE;
		}
	}

	CloseServiceHandle(serviceHandle);
	CloseServiceHandle(controlHandle);

	Sleep(100);

	return result;
}

//-----------------------------------------------------------------------------------------------
//--- DokanMountControl
//-----------------------------------------------------------------------------------------------
BOOL 
DOKANAPI
DokanMountControl(
	PDOKAN_CONTROL Control)
{
	HANDLE	pipe;
	DWORD	readBytes;
	DWORD	pipeMode;
	DWORD	error;

	for (;;) 
	{
		pipe = CreateFile(
					DOKAN_CONTROL_PIPE,  
					GENERIC_READ|
					GENERIC_WRITE, 
					0, 
					NULL,
					OPEN_EXISTING, 
					0, 
					NULL);

		if (pipe != INVALID_HANDLE_VALUE) 
		{
			break;
		}

		error = GetLastError();

		if (error == ERROR_PIPE_BUSY) 
		{
			if (!WaitNamedPipe(DOKAN_CONTROL_PIPE, NMPWAIT_USE_DEFAULT_WAIT)) 
			{
				DBGPRINT("[RCloudApp] DokanMountControl() : ...DokanMounter service : ERROR_PIPE_BUSY");
				
				return FALSE;
			}

			continue;
		} 
		else if (error == ERROR_ACCESS_DENIED) 
		{
			DBGPRINT("[RCloudApp] DokanMountControl() : ...failed to connect DokanMounter service: access denied");
			
			return FALSE;
		} 
		else 
		{
			DBGPRINT("[RCloudApp] DokanMountControl() : ...failed to connect DokanMounter service Error=[%d]", GetLastError());
			
			return FALSE;
		}
	}

	pipeMode = PIPE_READMODE_MESSAGE | PIPE_WAIT;

	if (!SetNamedPipeHandleState(pipe, &pipeMode, NULL, NULL)) 
	{
		DBGPRINT("[RCloudApp] DokanMountControl() : ...failed to set named pipe state Error=[%d]", GetLastError());
		CloseHandle(pipe);

		return FALSE;
	}

	if (!TransactNamedPipe(pipe, Control, sizeof(DOKAN_CONTROL), Control, sizeof(DOKAN_CONTROL), &readBytes, NULL)) 
	{
		DBGPRINT("[RCloudApp] DokanMountControl() : ...failed to transact named pipe Error=[%d]", GetLastError());
	}

	CloseHandle(pipe); 

	if (Control->Status != DOKAN_CONTROL_FAIL) 
	{
		return TRUE;
	} 
	else 
	{
		return FALSE;
	}
}

//-----------------------------------------------------------------------------------------------
//--- DokanServiceInstall
//-----------------------------------------------------------------------------------------------
BOOL 
DOKANAPI
DokanServiceInstall(
	LPCWSTR	ServiceName,
	DWORD	ServiceType,
	LPCWSTR ServiceFullPath)
{
	SC_HANDLE	controlHandle;
	SC_HANDLE	serviceHandle;
	
	controlHandle = OpenSCManager(NULL, NULL, SC_MANAGER_CREATE_SERVICE);
	
	if (controlHandle == NULL) 
	{
		DOKANDBGPRINT("failed to open SCM");

		return FALSE;
	}

	DOKANDBGPRINTW(L"[RCloudApp] DokanServiceInstall() : ...ServiceFullPath=[%s]  Service is already installed", ServiceFullPath);
	serviceHandle = CreateService(
						controlHandle, 
						ServiceName, 
						ServiceName, 
						0,
						ServiceType, 
						SERVICE_AUTO_START, 
						SERVICE_ERROR_IGNORE,
						ServiceFullPath, 
						NULL, 
						NULL, 
						NULL, 
						NULL, 
						NULL);
	
	if (serviceHandle == NULL) 
	{
		if (GetLastError() == ERROR_SERVICE_EXISTS) 
		{
			DOKANDBGPRINTW(L"[RCloudApp] DokanServiceInstall() : ...ServiceName=[%s]  Service is already installed", ServiceName);
		} 
		else 
		{
			DOKANDBGPRINTW(L"[RCloudApp] DokanServiceInstall() : ...failed to install service ServiceName=[%s], Error=[%d]", ServiceName, GetLastError());
		}

		CloseServiceHandle(controlHandle);

		return FALSE;
	}
	
	CloseServiceHandle(serviceHandle);
	CloseServiceHandle(controlHandle);

	DOKANDBGPRINTW(L"[RCloudApp] DokanServiceInstall() : ...Service [%s] installed", ServiceName);

	if (DokanServiceControl(ServiceName, DOKAN_SERVICE_START)) 
	{
		DOKANDBGPRINTW(L"[RCloudApp] DokanServiceInstall() : ...Service [%s] started", ServiceName);
		
		return TRUE;
	} 
	else 
	{
		DOKANDBGPRINTW(L"[RCloudApp] DokanServiceInstall() : ...Service [%s] start failed", ServiceName);
		
		return FALSE;
	}
}

//-----------------------------------------------------------------------------------------------
//--- DokanServiceDelete
//-----------------------------------------------------------------------------------------------
BOOL 
DOKANAPI
DokanServiceDelete(
	LPCWSTR	ServiceName)
{
	if (DokanServiceCheck(ServiceName)) 
	{
		DokanServiceControl(ServiceName, DOKAN_SERVICE_STOP);
		
		if (DokanServiceControl(ServiceName, DOKAN_SERVICE_DELETE)) 
		{
			return TRUE;
		} 
		else 
		{
			return FALSE;
		}
	}

	return TRUE;
}

//-----------------------------------------------------------------------------------------------
//--- DokanUnmount
//-----------------------------------------------------------------------------------------------
BOOL 
DOKANAPI
DokanUnmount(
	WCHAR	DriveLetter)
{
	WCHAR mountPoint[] = L"M:\\";
	mountPoint[0] = DriveLetter;

	return DokanRemoveMountPoint(mountPoint);
}

//-----------------------------------------------------------------------------------------------
//--- DokanRemoveMountPoint
//-----------------------------------------------------------------------------------------------
BOOL 
DOKANAPI
DokanRemoveMountPoint(
	LPCWSTR MountPoint)
{
	DOKAN_CONTROL	control;
	BOOL			result;

	ZeroMemory(&control, sizeof(DOKAN_CONTROL));
	control.Type = DOKAN_CONTROL_UNMOUNT;
	wcscpy_s(control.MountPoint, sizeof(control.MountPoint) / sizeof(WCHAR), MountPoint);

	DBGPRINTW(L"[RCloudApp] DokanRemoveMountPoint() : ...DokanRemoveMountPoint=[%ws]", MountPoint);

	result = DokanMountControl(&control);
	if (result) 
	{
		DBGPRINT("[RCloudApp] DokanRemoveMountPoint() : ...DokanControl recieved DeviceName=[%ws]", control.DeviceName);
		SendReleaseIRP(control.DeviceName);
	}
	else 
	{
		DBGPRINT("[RCloudApp] DokanRemoveMountPoint() : ...DokanRemoveMountPoint failed");
	}

	return result;
}

//-----------------------------------------------------------------------------------------------
//--- DoKanReleaseIrp
//-----------------------------------------------------------------------------------------------
VOID
DOKANAPI
DoKanReleaseIrp()
{
	DBGPRINT("[RCloudApp] DoKanReleaseIrp() : ...g_Instance=[%X]", g_Instance);

	if (g_Instance)
	{
		SendReleaseIRP(g_Instance->DeviceName);
		DBGPRINT("[RCloudApp] DoKanReleaseIrp() : SendReleaseIRP()...");

		DeleteDokanInstance(g_Instance);
		DBGPRINT("[RCloudApp] DoKanReleaseIrp() : DeleteDokanInstance()...");
	}
}

//-----------------------------------------------------------------------------------------------
//--- DokanMount
//-----------------------------------------------------------------------------------------------
BOOL
DokanMount(
	LPCWSTR	MountPoint,
	LPCWSTR	DeviceName)
{
	DOKAN_CONTROL control;

	ZeroMemory(&control, sizeof(DOKAN_CONTROL));
	control.Type = DOKAN_CONTROL_MOUNT;

	wcscpy_s(control.MountPoint, sizeof(control.MountPoint) / sizeof(WCHAR), MountPoint);
	wcscpy_s(control.DeviceName, sizeof(control.DeviceName) / sizeof(WCHAR), DeviceName);

	return  DokanMountControl(&control);
}

#define DOKAN_NP_SERVICE_KEY	L"System\\CurrentControlSet\\Services\\Dokan"
#define DOKAN_NP_DEVICE_NAME	L"\\Device\\DokanRedirector"
#define DOKAN_NP_NAME			L"DokanNP"
#define DOKAN_NP_PATH			L"System32\\dokannp.dll"
#define DOKAN_NP_ORDER_KEY		L"System\\CurrentControlSet\\Control\\NetworkProvider\\Order"

//-----------------------------------------------------------------------------------------------
//--- DokanNetworkProviderInstall
//-----------------------------------------------------------------------------------------------
BOOL 
DOKANAPI
DokanNetworkProviderInstall()
{
	HKEY  key;
	DWORD position;
	DWORD type;
	WCHAR buffer[1024];
	DWORD buffer_size = sizeof(buffer);
	ZeroMemory(&buffer, sizeof(buffer));

	RegCreateKeyEx(HKEY_LOCAL_MACHINE, DOKAN_NP_SERVICE_KEY L"\\NetworkProvider", 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &key, &position);

	RegSetValueEx(key, L"DeviceName", 0, REG_SZ, (BYTE*) DOKAN_NP_DEVICE_NAME, (wcslen(DOKAN_NP_DEVICE_NAME) + 1) * sizeof(WCHAR));

	RegSetValueEx(key, L"Name", 0, REG_SZ, (BYTE*) DOKAN_NP_NAME, (wcslen(DOKAN_NP_NAME) + 1) * sizeof(WCHAR));

	RegSetValueEx(key, L"ProviderPath", 0, REG_SZ, (BYTE*) DOKAN_NP_PATH, (wcslen(DOKAN_NP_PATH) + 1) * sizeof(WCHAR));

    RegCloseKey(key);

	RegOpenKeyEx(HKEY_LOCAL_MACHINE, DOKAN_NP_ORDER_KEY, 0, KEY_ALL_ACCESS, &key);

	RegQueryValueEx(key, L"ProviderOrder", 0, &type, (BYTE*) &buffer, &buffer_size);

	if (wcsstr(buffer, L",Dokan") == NULL) 
	{
		wcscat_s(buffer, sizeof(buffer) / sizeof(WCHAR), L",Dokan");
		RegSetValueEx(key, L"ProviderOrder", 0, REG_SZ,	(BYTE*) &buffer, (wcslen(buffer) + 1) * sizeof(WCHAR));
	}

    RegCloseKey(key);

	return TRUE;
}

//-----------------------------------------------------------------------------------------------
//--- DokanNetworkProviderUninstall
//-----------------------------------------------------------------------------------------------
BOOL 
DOKANAPI
DokanNetworkProviderUninstall()
{
	HKEY  key;
	DWORD type;
	WCHAR buffer[1024];
	WCHAR buffer2[1024];

	DWORD buffer_size = sizeof(buffer);
	ZeroMemory(&buffer, sizeof(buffer));
	ZeroMemory(&buffer2, sizeof(buffer));

	RegOpenKeyEx(HKEY_LOCAL_MACHINE, DOKAN_NP_SERVICE_KEY, 0, KEY_ALL_ACCESS, &key);
	RegDeleteKey(key, L"NetworkProvider");

    RegCloseKey(key);

	RegOpenKeyEx(HKEY_LOCAL_MACHINE, DOKAN_NP_ORDER_KEY, 0, KEY_ALL_ACCESS, &key);

	RegQueryValueEx(key, L"ProviderOrder", 0, &type, (BYTE*)&buffer, &buffer_size);

	if (wcsstr(buffer, L",Dokan") != NULL) 
	{
		WCHAR* dokan_pos = wcsstr(buffer, L",Dokan");
		wcsncpy_s(buffer2, sizeof(buffer2) / sizeof(WCHAR), buffer, dokan_pos - buffer);
		wcscat_s(buffer2, sizeof(buffer2) / sizeof(WCHAR), dokan_pos + wcslen(L",Dokan"));
		RegSetValueEx(key, L"ProviderOrder", 0, REG_SZ,	(BYTE*)&buffer2, (wcslen(buffer2) + 1) * sizeof(WCHAR));
	}

    RegCloseKey(key);

	return TRUE;
}

//-----------------------------------------------------------------------------------------------