/*
  Dokan : user-mode file system library for Windows

  Copyright (C) 2008 Hiroki Asakawa info@dokan-dev.net

  http://dokan-dev.net/en

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the Free
Software Foundation; either version 3 of the License, or (at your option) any
later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU Lesser General Public License along
with this program. If not, see <http://www.gnu.org/licenses/>.
*/
//-----------------------------------------------------------------------------------------------
#include "dokan.h"

//-----------------------------------------------------------------------------------------------
//--- DokanUserFsRequest
//-----------------------------------------------------------------------------------------------
NTSTATUS
DokanUserFsRequest(
	__in PDEVICE_OBJECT	DeviceObject,
	__in PIRP			Irp)
{
	NTSTATUS			status = STATUS_NOT_IMPLEMENTED;
	PIO_STACK_LOCATION	irpSp;

	irpSp = IoGetCurrentIrpStackLocation(Irp);

	switch(irpSp->Parameters.FileSystemControl.FsControlCode) 
	{
		case FSCTL_REQUEST_OPLOCK_LEVEL_1:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_REQUEST_OPLOCK_LEVEL_1");
			status = STATUS_SUCCESS;
			break;

		case FSCTL_REQUEST_OPLOCK_LEVEL_2:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_REQUEST_OPLOCK_LEVEL_2");
			status = STATUS_SUCCESS;
			break;

		case FSCTL_REQUEST_BATCH_OPLOCK:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_REQUEST_BATCH_OPLOCK");
			status = STATUS_SUCCESS;
			break;

		case FSCTL_OPLOCK_BREAK_ACKNOWLEDGE:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_OPLOCK_BREAK_ACKNOWLEDGE");
			status = STATUS_SUCCESS;
			break;

		case FSCTL_OPBATCH_ACK_CLOSE_PENDING:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_OPBATCH_ACK_CLOSE_PENDING");
			status = STATUS_SUCCESS;
			break;

		case FSCTL_OPLOCK_BREAK_NOTIFY:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_OPLOCK_BREAK_NOTIFY");
			status = STATUS_SUCCESS;
			break;

		case FSCTL_LOCK_VOLUME:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_LOCK_VOLUME");
			status = STATUS_SUCCESS;
			break;

		case FSCTL_UNLOCK_VOLUME:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_UNLOCK_VOLUME");
			status = STATUS_SUCCESS;
			break;

		case FSCTL_DISMOUNT_VOLUME:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_DISMOUNT_VOLUME");
			break;

		case FSCTL_IS_VOLUME_MOUNTED:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_IS_VOLUME_MOUNTED");
			status = STATUS_SUCCESS;
			break;

		case FSCTL_IS_PATHNAME_VALID:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_IS_PATHNAME_VALID");
			break;

		case FSCTL_MARK_VOLUME_DIRTY:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_MARK_VOLUME_DIRTY");
			break;

		case FSCTL_QUERY_RETRIEVAL_POINTERS:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_QUERY_RETRIEVAL_POINTERS");
			break;

		case FSCTL_GET_COMPRESSION:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_GET_COMPRESSION");
			break;

		case FSCTL_SET_COMPRESSION:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_SET_COMPRESSION");
			break;

		case FSCTL_MARK_AS_SYSTEM_HIVE:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_MARK_AS_SYSTEM_HIVE");
			break;

		case FSCTL_OPLOCK_BREAK_ACK_NO_2:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_OPLOCK_BREAK_ACK_NO_2");
			break;

		case FSCTL_INVALIDATE_VOLUMES:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_INVALIDATE_VOLUMES");
			break;

		case FSCTL_QUERY_FAT_BPB:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_QUERY_FAT_BPB");
			break;

		case FSCTL_REQUEST_FILTER_OPLOCK:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_REQUEST_FILTER_OPLOCK");
			break;

		case FSCTL_FILESYSTEM_GET_STATISTICS:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_FILESYSTEM_GET_STATISTICS");
			break;

		case FSCTL_GET_NTFS_VOLUME_DATA:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_GET_NTFS_VOLUME_DATA");
			break;

		case FSCTL_GET_NTFS_FILE_RECORD:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_GET_NTFS_FILE_RECORD");
			break;

		case FSCTL_GET_VOLUME_BITMAP:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_GET_VOLUME_BITMAP");
			break;

		case FSCTL_GET_RETRIEVAL_POINTERS:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_GET_RETRIEVAL_POINTERS");
			break;

		case FSCTL_MOVE_FILE:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_MOVE_FILE");
			break;

		case FSCTL_IS_VOLUME_DIRTY:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_IS_VOLUME_DIRTY");
			break;

		case FSCTL_ALLOW_EXTENDED_DASD_IO:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_ALLOW_EXTENDED_DASD_IO");
			break;

		case FSCTL_FIND_FILES_BY_SID:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_FIND_FILES_BY_SID");
			break;

		case FSCTL_SET_OBJECT_ID:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_SET_OBJECT_ID");
			break;

		case FSCTL_GET_OBJECT_ID:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_GET_OBJECT_ID");
			break;

		case FSCTL_DELETE_OBJECT_ID:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_DELETE_OBJECT_ID");
			break;

		case FSCTL_SET_REPARSE_POINT:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_SET_REPARSE_POINT");
			break;

		case FSCTL_GET_REPARSE_POINT:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_GET_REPARSE_POINT");
			status = STATUS_NOT_A_REPARSE_POINT;
			break;

		case FSCTL_DELETE_REPARSE_POINT:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_DELETE_REPARSE_POINT");
			break;

		case FSCTL_ENUM_USN_DATA:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_ENUM_USN_DATA");
			break;

		case FSCTL_SECURITY_ID_CHECK:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_SECURITY_ID_CHECK");
			break;

		case FSCTL_READ_USN_JOURNAL:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_READ_USN_JOURNAL");
			break;

		case FSCTL_SET_OBJECT_ID_EXTENDED:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_SET_OBJECT_ID_EXTENDED");
			break;

		case FSCTL_CREATE_OR_GET_OBJECT_ID:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_CREATE_OR_GET_OBJECT_ID");
			break;

		case FSCTL_SET_SPARSE:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_SET_SPARSE");
			break;

		case FSCTL_SET_ZERO_DATA:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_SET_ZERO_DATA");
			break;

		case FSCTL_QUERY_ALLOCATED_RANGES:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_QUERY_ALLOCATED_RANGES");
			break;

		case FSCTL_SET_ENCRYPTION:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_SET_ENCRYPTION");
			break;

		case FSCTL_ENCRYPTION_FSCTL_IO:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_ENCRYPTION_FSCTL_IO");
			break;

		case FSCTL_WRITE_RAW_ENCRYPTED:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_WRITE_RAW_ENCRYPTED");
			break;

		case FSCTL_READ_RAW_ENCRYPTED:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_READ_RAW_ENCRYPTED");
			break;

		case FSCTL_CREATE_USN_JOURNAL:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_CREATE_USN_JOURNAL");
			break;

		case FSCTL_READ_FILE_USN_DATA:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_READ_FILE_USN_DATA");
			break;

		case FSCTL_WRITE_USN_CLOSE_RECORD:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_WRITE_USN_CLOSE_RECORD");
			break;

		case FSCTL_EXTEND_VOLUME:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_EXTEND_VOLUME");
			break;

		case FSCTL_QUERY_USN_JOURNAL:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_QUERY_USN_JOURNAL");
			break;

		case FSCTL_DELETE_USN_JOURNAL:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_DELETE_USN_JOURNAL");
			break;

		case FSCTL_MARK_HANDLE:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_MARK_HANDLE");
			break;

		case FSCTL_SIS_COPYFILE:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_SIS_COPYFILE");
			break;

		case FSCTL_SIS_LINK_FILES:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_SIS_LINK_FILES");
			break;

		case FSCTL_RECALL_FILE:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...FSCTL_RECALL_FILE");
			break;

		default:
			DDBGPRINT("[RCloudFS] DokanUserFsRequest() : ...Unknown FSCTL FsControlCode=[%d]", (irpSp->Parameters.FileSystemControl.FsControlCode >> 2) & 0xFFF);
			status = STATUS_INVALID_DEVICE_REQUEST;
	}

	return status;
}

//-----------------------------------------------------------------------------------------------
//--- DokanDispatchFileSystemControl
//-----------------------------------------------------------------------------------------------
NTSTATUS
DokanDispatchFileSystemControl(
	__in PDEVICE_OBJECT DeviceObject,
	__in PIRP Irp)
{
	NTSTATUS			status = STATUS_INVALID_PARAMETER;
	PIO_STACK_LOCATION	irpSp;
	PDokanVCB			vcb;

	PAGED_CODE();

	__try 
	{
		FsRtlEnterFileSystem();

		DDBGPRINT("[RCloudFS] DokanDispatchFileSystemControl() : ...Start");
		DDBGPRINT("[RCloudFS] DokanDispatchFileSystemControl() : IoGetRequestorProcessId()...ProcessId=[%lu]", IoGetRequestorProcessId(Irp));

		vcb = DeviceObject->DeviceExtension;

		if (GetIdentifierType(vcb) != VCB) 
		{
			status = STATUS_INVALID_PARAMETER;

			__leave;
		}

		irpSp = IoGetCurrentIrpStackLocation(Irp);

		switch(irpSp->MinorFunction) 
		{
			case IRP_MN_KERNEL_CALL:
				DDBGPRINT("[RCloudFS] DokanDispatchFileSystemControl() : ...IRP_MN_KERNEL_CALL");
				break;

			case IRP_MN_LOAD_FILE_SYSTEM:
				DDBGPRINT("[RCloudFS] DokanDispatchFileSystemControl() : ...IRP_MN_LOAD_FILE_SYSTEM");
				break;

			case IRP_MN_MOUNT_VOLUME:
				{
					PVPB vpb;
					DDBGPRINT("[RCloudFS] DokanDispatchFileSystemControl() : ...IRP_MN_MOUNT_VOLUME");

					if (irpSp->Parameters.MountVolume.DeviceObject != vcb->Dcb->DeviceObject) 
					{
						DDBGPRINT("[RCloudFS] DokanDispatchFileSystemControl() : ...Not DokanDiskDevice");
						status = STATUS_INVALID_PARAMETER;
					}
					vpb = irpSp->Parameters.MountVolume.Vpb;
					vpb->DeviceObject = vcb->DeviceObject;
					vpb->RealDevice = vcb->DeviceObject;
					vpb->Flags |= VPB_MOUNTED;
					vpb->VolumeLabelLength = wcslen(VOLUME_LABEL) * sizeof(WCHAR);
					RtlStringCchCopyW(vpb->VolumeLabel, sizeof(vpb->VolumeLabel) / sizeof(WCHAR), VOLUME_LABEL);
					vpb->SerialNumber = _RCLOUD_VOLUME_SERIAL;
					status = STATUS_SUCCESS;
				}
				break;

			case IRP_MN_USER_FS_REQUEST:
				DDBGPRINT("[RCloudFS] DokanDispatchFileSystemControl() : ...IRP_MN_USER_FS_REQUEST");
				status = DokanUserFsRequest(DeviceObject, Irp);
				break;

			case IRP_MN_VERIFY_VOLUME:
				DDBGPRINT("[RCloudFS] DokanDispatchFileSystemControl() : ...IRP_MN_VERIFY_VOLUME");
				break;

			default:
				DDBGPRINT("[RCloudFS] DokanDispatchFileSystemControl() : ...unknown=[%d]", irpSp->MinorFunction);
				status = STATUS_INVALID_PARAMETER;
				break;
		}
	} 
	__finally 
	{
		Irp->IoStatus.Status = status;
		Irp->IoStatus.Information = 0;
		IoCompleteRequest(Irp, IO_NO_INCREMENT);

		DokanPrintNTStatus(status);
		DDBGPRINT("[RCloudFS] DokanDispatchFileSystemControl() : ...End");

		FsRtlExitFileSystem();
	}

	return status;
}

//-----------------------------------------------------------------------------------------------

