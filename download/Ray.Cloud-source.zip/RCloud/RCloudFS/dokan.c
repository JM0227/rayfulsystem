/*
  Dokan : user-mode file system library for Windows

  Copyright (C) 2008 Hiroki Asakawa info@dokan-dev.net

  http://dokan-dev.net/en

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the Free
Software Foundation; either version 3 of the License, or (at your option) any
later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU Lesser General Public License along
with this program. If not, see <http://www.gnu.org/licenses/>.
*/

//-----------------------------------------------------------------------------------------------
#include "dokan.h"

//-----------------------------------------------------------------------------------------------
#ifdef ALLOC_PRAGMA
#pragma alloc_text (INIT, DriverEntry)
#pragma alloc_text (PAGE, DokanUnload)
#pragma alloc_text (PAGE, DokanDispatchShutdown)
#pragma alloc_text (PAGE, DokanDispatchPnp)
#endif

ULONG g_Debug = DOKAN_DEBUG_DEFAULT;

#if _WIN32_WINNT < 0x0501
	PFN_FSRTLTEARDOWNPERSTREAMCONTEXTS DokanFsRtlTeardownPerStreamContexts;
#endif

NPAGED_LOOKASIDE_LIST	DokanIrpEntryLookasideList;
UNICODE_STRING			FcbFileNameNull;

FAST_IO_CHECK_IF_POSSIBLE DokanFastIoCheckIfPossible;

//-----------------------------------------------------------------------------------------------
//--- DokanFastIoCheckIfPossible
//-----------------------------------------------------------------------------------------------
BOOLEAN
DokanFastIoCheckIfPossible(
    __in PFILE_OBJECT	FileObject,
    __in PLARGE_INTEGER	FileOffset,
    __in ULONG			Length,
    __in BOOLEAN		Wait,
    __in ULONG			LockKey,
    __in BOOLEAN		CheckForReadOperation,
    __out PIO_STATUS_BLOCK	IoStatus,
    __in PDEVICE_OBJECT		DeviceObject)
{
	DDBGPRINT("[RCloudFS] DokanFastIoCheckIfPossible() : ...End");
	
	return FALSE;
}

//-----------------------------------------------------------------------------------------------
//--- DokanFastIoRead
//-----------------------------------------------------------------------------------------------
BOOLEAN
DokanFastIoRead(
    __in PFILE_OBJECT	FileObject,
    __in PLARGE_INTEGER	FileOffset,
    __in ULONG			Length,
    __in BOOLEAN		Wait,
    __in ULONG			LockKey,
    __in PVOID			Buffer,
    __out PIO_STATUS_BLOCK	IoStatus,
    __in PDEVICE_OBJECT		DeviceObject)
{
	DDBGPRINT("[RCloudFS] DokanFastIoRead() : ...");

	return  FsRtlCopyRead(
				FileObject,
				FileOffset,
				Length,
				Wait,
				LockKey,
				Buffer,
				IoStatus,
				DeviceObject);
}

//-----------------------------------------------------------------------------------------------
//--- DokanAcquireForCreateSection
//-----------------------------------------------------------------------------------------------
FAST_IO_ACQUIRE_FILE 
DokanAcquireForCreateSection;

VOID
DokanAcquireForCreateSection(
	__in PFILE_OBJECT FileObject)
{
	PFSRTL_ADVANCED_FCB_HEADER	header;
	
	//DbgPrint("[RCloudFS] DokanAcquireForCreateSection() : ...FileObject=[%X], FsContext=[%X], FsContext2=[%X]", FileObject, FileObject->FsContext, FileObject->FsContext2);

	header = FileObject->FsContext;
	if (header && header->Resource) 
	{
		//DbgPrint("[RCloudFS] DokanAcquireForCreateSection() : ...Flags=[%X]", header->Flags);
	
		ExAcquireResourceExclusiveLite(header->Resource, TRUE);
	}

	DDBGPRINT("[RCloudFS] DokanAcquireForCreateSection() : ...");
}

//-----------------------------------------------------------------------------------------------
//--- DokanReleaseForCreateSection
//-----------------------------------------------------------------------------------------------
FAST_IO_RELEASE_FILE 
DokanReleaseForCreateSection;

VOID
DokanReleaseForCreateSection(
	__in PFILE_OBJECT FileObject)
{
	PFSRTL_ADVANCED_FCB_HEADER	header;
	
	//DbgPrint("[RCloudFS] DokanReleaseForCreateSection() : ...FileObject=[%X], FsContext=[%X], FsContext2=[%X]", FileObject, FileObject->FsContext, FileObject->FsContext2);

	header = FileObject->FsContext;
	if (header && header->Resource) 
	{
		//DbgPrint("[RCloudFS] DokanReleaseForCreateSection() : ...Flags=[%X]", header->Flags);

		ExReleaseResourceLite(header->Resource);
	}
	
	DDBGPRINT("[RCloudFS] DokanReleaseForCreateSection() : ...");
}

//-----------------------------------------------------------------------------------------------
//--- DokanFilterCallbackAcquireForCreateSection
//-----------------------------------------------------------------------------------------------
NTSTATUS
DokanFilterCallbackAcquireForCreateSection(
	__in PFS_FILTER_CALLBACK_DATA CallbackData,
    __out PVOID *CompletionContext)
{
	PFSRTL_ADVANCED_FCB_HEADER	header;
	DDBGPRINT("[RCloudFS] DokanFilterCallbackAcquireForCreateSection() : ...");

	header = CallbackData->FileObject->FsContext;
	
	if (header && header->Resource) 
	{
		ExAcquireResourceExclusiveLite(header->Resource, TRUE);
	}
	
	if (CallbackData->Parameters.AcquireForSectionSynchronization.SyncType != SyncTypeCreateSection) 
	{
		return STATUS_FSFILTER_OP_COMPLETED_SUCCESSFULLY;
	} 
	else 
	{
		return STATUS_FILE_LOCKED_WITH_WRITERS;
	}
}

//-----------------------------------------------------------------------------------------------
//--- DokanFilterCallbackPreOperation
//-----------------------------------------------------------------------------------------------
NTSTATUS
DokanFilterCallbackPreOperation(
	PFS_FILTER_CALLBACK_DATA CallbackData,
	PVOID *CompletionContext)
{
	return STATUS_SUCCESS;	
}

//-----------------------------------------------------------------------------------------------
//--- DokanFilterCallbackPostOperation
//-----------------------------------------------------------------------------------------------
VOID
DokanFilterCallbackPostOperation(
	PFS_FILTER_CALLBACK_DATA CallbackData,
	NTSTATUS OpeationStatus,
	PVOID CompletionContext)
{
}

//-----------------------------------------------------------------------------------------------
//--- DriverEntry
//-----------------------------------------------------------------------------------------------
NTSTATUS
DriverEntry(
	__in PDRIVER_OBJECT  DriverObject,
	__in PUNICODE_STRING RegistryPath)

/*++

Routine Description:

	This routine gets called by the system to initialize the driver.

Arguments:

	DriverObject	- the system supplied driver object.
	RegistryPath	- the system supplied registry path for this driver.

Return Value:

	NTSTATUS

--*/

{
	PDEVICE_OBJECT		deviceObject;
	NTSTATUS			status;
	PFAST_IO_DISPATCH	fastIoDispatch;
	UNICODE_STRING		functionName;
	FS_FILTER_CALLBACKS filterCallbacks;
	PDOKAN_GLOBAL		dokanGlobal = NULL;

	DDBGPRINT("[RCloudFS] DriverEntry() : ...Ver.%x, %s %s\n", DOKAN_DRIVER_VERSION, __DATE__, __TIME__);

	status = DokanCreateGlobalDiskDevice(DriverObject, &dokanGlobal);

	if (status != STATUS_SUCCESS) 
	{
		return status;
	}
	//
	// Set up dispatch entry points for the driver.
	//
	DriverObject->DriverUnload										= DokanUnload;

	DriverObject->MajorFunction[IRP_MJ_CREATE]						= DokanDispatchCreate;
	DriverObject->MajorFunction[IRP_MJ_CLOSE]						= DokanDispatchClose;
	DriverObject->MajorFunction[IRP_MJ_CLEANUP] 					= DokanDispatchCleanup;

	DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL]				= DokanDispatchDeviceControl;
	DriverObject->MajorFunction[IRP_MJ_FILE_SYSTEM_CONTROL]			= DokanDispatchFileSystemControl;
	DriverObject->MajorFunction[IRP_MJ_DIRECTORY_CONTROL]			= DokanDispatchDirectoryControl;

	DriverObject->MajorFunction[IRP_MJ_QUERY_INFORMATION]			= DokanDispatchQueryInformation;
    DriverObject->MajorFunction[IRP_MJ_SET_INFORMATION]				= DokanDispatchSetInformation;

    DriverObject->MajorFunction[IRP_MJ_QUERY_VOLUME_INFORMATION]	= DokanDispatchQueryVolumeInformation;
    DriverObject->MajorFunction[IRP_MJ_SET_VOLUME_INFORMATION]		= DokanDispatchSetVolumeInformation;

	DriverObject->MajorFunction[IRP_MJ_READ]						= DokanDispatchRead;
	DriverObject->MajorFunction[IRP_MJ_WRITE]						= DokanDispatchWrite;
	DriverObject->MajorFunction[IRP_MJ_FLUSH_BUFFERS]				= DokanDispatchFlush;

	DriverObject->MajorFunction[IRP_MJ_SHUTDOWN]					= DokanDispatchShutdown;
	DriverObject->MajorFunction[IRP_MJ_PNP]							= DokanDispatchPnp;

	DriverObject->MajorFunction[IRP_MJ_LOCK_CONTROL]				= DokanDispatchLock;

	DriverObject->MajorFunction[IRP_MJ_QUERY_SECURITY]				= DokanDispatchQuerySecurity;
	//--- 20121204
	DriverObject->MajorFunction[IRP_MJ_SET_SECURITY]				= DokanDispatchSetSecurity;

	fastIoDispatch = ExAllocatePool(sizeof(FAST_IO_DISPATCH));
	// TODO: check fastIoDispatch

	RtlZeroMemory(fastIoDispatch, sizeof(FAST_IO_DISPATCH));

	fastIoDispatch->SizeOfFastIoDispatch = sizeof(FAST_IO_DISPATCH);
    fastIoDispatch->FastIoCheckIfPossible = DokanFastIoCheckIfPossible;
    
	//fastIoDispatch->FastIoRead = DokanFastIoRead;
	fastIoDispatch->FastIoRead = FsRtlCopyRead;
	fastIoDispatch->FastIoWrite = FsRtlCopyWrite;
	fastIoDispatch->MdlRead = FsRtlMdlReadDev;
	fastIoDispatch->MdlReadComplete = FsRtlMdlReadCompleteDev;
	fastIoDispatch->AcquireFileForNtCreateSection = DokanAcquireForCreateSection;
	fastIoDispatch->ReleaseFileForNtCreateSection = DokanReleaseForCreateSection;
    fastIoDispatch->PrepareMdlWrite = FsRtlPrepareMdlWriteDev;
    fastIoDispatch->MdlWriteComplete = FsRtlMdlWriteCompleteDev;

	DriverObject->FastIoDispatch = fastIoDispatch;

	ExInitializeNPagedLookasideList(
		&DokanIrpEntryLookasideList, NULL, NULL, 0, sizeof(IRP_ENTRY), TAG, 0);


	#if _WIN32_WINNT < 0x0501
		RtlInitUnicodeString(&functionName, L"FsRtlTeardownPerStreamContexts");
		DokanFsRtlTeardownPerStreamContexts = MmGetSystemRoutineAddress(&functionName);
	#endif

    RtlZeroMemory(&filterCallbacks, sizeof(FS_FILTER_CALLBACKS));

	// only be used by filter driver?
	filterCallbacks.SizeOfFsFilterCallbacks = sizeof(FS_FILTER_CALLBACKS);
	filterCallbacks.PreAcquireForSectionSynchronization = DokanFilterCallbackAcquireForCreateSection;
	
	/*---
	filterCallbacks.PostAcquireForSectionSynchronization = DokanFilterCallbackPostOperation;
	filterCallbacks.PreReleaseForSectionSynchronization = DokanFilterCallbackPreOperation;
	filterCallbacks.PostReleaseForSectionSynchronization = DokanFilterCallbackPostOperation;
	filterCallbacks.PreAcquireForCcFlush = DokanFilterCallbackPreOperation;
	filterCallbacks.PostAcquireForCcFlush = DokanFilterCallbackPostOperation;
	filterCallbacks.PreReleaseForCcFlush = DokanFilterCallbackPreOperation;
	filterCallbacks.PostReleaseForCcFlush = DokanFilterCallbackPostOperation;
	filterCallbacks.PreAcquireForModifiedPageWriter = DokanFilterCallbackPreOperation;
	filterCallbacks.PostAcquireForModifiedPageWriter = DokanFilterCallbackPostOperation;
	filterCallbacks.PreReleaseForModifiedPageWriter = DokanFilterCallbackPreOperation;
	filterCallbacks.PostReleaseForModifiedPageWriter = DokanFilterCallbackPostOperation;
	---*/

	status = FsRtlRegisterFileSystemFilterCallbacks(DriverObject, &filterCallbacks);
	DDBGPRINT("[RCloudFS] DriverEntry() : FsRtlRegisterFileSystemFilterCallbacks ...status=[%X]", status);

	if (!NT_SUCCESS(status)) 
	{
		IoDeleteDevice(dokanGlobal->DeviceObject);
		DDBGPRINT("[RCloudFS] DriverEntry() : FsRtlRegisterFileSystemFilterCallbacks() ...returned 0x%x\n", status);
		
		return status;
	}

	DDBGPRINT("[RCloudFS] DriverEntry() : ...End");

	return (status);
}

//-----------------------------------------------------------------------------------------------
//--- DokanUnload
//-----------------------------------------------------------------------------------------------
VOID
DokanUnload(
	__in PDRIVER_OBJECT DriverObject)
/*++

Routine Description:

	This routine gets called to remove the driver from the system.

Arguments:

	DriverObject	- the system supplied driver object.

Return Value:

	NTSTATUS

--*/

{
	PDEVICE_OBJECT	deviceObject = DriverObject->DeviceObject;
	WCHAR			symbolicLinkBuf[] = DOKAN_GLOBAL_SYMBOLIC_LINK_NAME;
	UNICODE_STRING	symbolicLinkName;

	PAGED_CODE();
	DDBGPRINT("[RCloudFS] DokanUnload() : ...Start");

	if (GetIdentifierType(deviceObject->DeviceExtension) == DGL) 
	{
		DDBGPRINT("  Delete Global DeviceObject");
		RtlInitUnicodeString(&symbolicLinkName, symbolicLinkBuf);
		IoDeleteSymbolicLink(&symbolicLinkName);
		IoDeleteDevice(deviceObject);
	}

	ExDeleteNPagedLookasideList(&DokanIrpEntryLookasideList);

	DDBGPRINT("[RCloudFS] DokanUnload() : ...End");

	return;
}

//-----------------------------------------------------------------------------------------------
//--- DokanDispatchShutdown
//-----------------------------------------------------------------------------------------------
NTSTATUS
DokanDispatchShutdown(
	__in PDEVICE_OBJECT DeviceObject,
	__in PIRP Irp)
{
	PAGED_CODE();
	DDBGPRINT("[RCloud] DokanDispatchShutdown() : ...Start");

	Irp->IoStatus.Status = STATUS_SUCCESS;
	Irp->IoStatus.Information = 0;
	IoCompleteRequest(Irp, IO_NO_INCREMENT);

	DDBGPRINT("[RCloud] DokanDispatchShutdown() : ...End");

	return STATUS_SUCCESS;
}

//-----------------------------------------------------------------------------------------------
//--- DokanDispatchPnp
//-----------------------------------------------------------------------------------------------
NTSTATUS
DokanDispatchPnp(
	__in PDEVICE_OBJECT DeviceObject,
	__in PIRP Irp)
{
	PIO_STACK_LOCATION	irpSp;
	NTSTATUS			status = STATUS_SUCCESS;

	PAGED_CODE();

	__try 
	{
		DDBGPRINT("[RCloudFS] DokanDispatchPnp() : ...Start");

		irpSp = IoGetCurrentIrpStackLocation(Irp);

		switch (irpSp->MinorFunction) 
		{
			case IRP_MN_QUERY_REMOVE_DEVICE:
				DDBGPRINT("[RCloudFS] DokanDispatchPnp() : IoGetCurrentIrpStackLocation()...IRP_MN_QUERY_REMOVE_DEVICE");
				break;

			case IRP_MN_SURPRISE_REMOVAL:
				DDBGPRINT("[RCloudFS] DokanDispatchPnp() : IoGetCurrentIrpStackLocation()...IRP_MN_SURPRISE_REMOVAL");
				break;

			case IRP_MN_REMOVE_DEVICE:
				DDBGPRINT("[RCloudFS] DokanDispatchPnp() : IoGetCurrentIrpStackLocation()...IRP_MN_REMOVE_DEVICE");
				break;

			case IRP_MN_CANCEL_REMOVE_DEVICE:
				DDBGPRINT("[RCloudFS] DokanDispatchPnp() : IoGetCurrentIrpStackLocation()...IRP_MN_CANCEL_REMOVE_DEVICE");
				break;

			case IRP_MN_QUERY_DEVICE_RELATIONS:
				DDBGPRINT("[RCloudFS] DokanDispatchPnp() : IoGetCurrentIrpStackLocation()...IRP_MN_QUERY_DEVICE_RELATIONS");
				status = STATUS_INVALID_PARAMETER;
				break;

			default:
				DDBGPRINT("[RCloudFS] DokanDispatchPnp() : IoGetCurrentIrpStackLocation()...Other Minnor Function=[%d]", irpSp->MinorFunction);
				break;
				//IoSkipCurrentIrpStackLocation(Irp);
				//status = IoCallDriver(Vcb->TargetDeviceObject, Irp);
		}
	} 
	__finally 
	{
		Irp->IoStatus.Status = status;
		Irp->IoStatus.Information = 0;
		IoCompleteRequest(Irp, IO_NO_INCREMENT);

		DDBGPRINT("[RCloudFS] DokanDispatchPnp() : ...End");
	}

	return status;
}

//-----------------------------------------------------------------------------------------------
//--- DokanNoOpAcquire
//-----------------------------------------------------------------------------------------------
BOOLEAN
DokanNoOpAcquire(
    __in PVOID Fcb,
    __in BOOLEAN Wait)
{
    UNREFERENCED_PARAMETER( Fcb );
    UNREFERENCED_PARAMETER( Wait );

	DDBGPRINT("[RCloudFS] DokanNoOpAcquire() : ...Start");

    ASSERT(IoGetTopLevelIrp() == NULL);

    IoSetTopLevelIrp((PIRP)FSRTL_CACHE_TOP_LEVEL_IRP);

	DDBGPRINT("[RCloudFS] DokanNoOpAcquire() : ...End");
    
	return TRUE;
}

//-----------------------------------------------------------------------------------------------
//--- DokanNoOpRelease
//-----------------------------------------------------------------------------------------------
VOID
DokanNoOpRelease(
    __in PVOID Fcb)
{
	DDBGPRINT("[RCloudFS] DokanNoOpRelease() : ...Start");
    ASSERT(IoGetTopLevelIrp() == (PIRP)FSRTL_CACHE_TOP_LEVEL_IRP);

    IoSetTopLevelIrp(NULL);

    UNREFERENCED_PARAMETER(Fcb);
	
	DDBGPRINT("[RCloudFS] DokanNoOpRelease() : ...End");

    return;
}

#define PrintStatus(val, flag) if(val == flag) DDBGPRINT("[RCloudFS] Status = " #flag "")

//-----------------------------------------------------------------------------------------------
//--- DokanPrintNTStatus
//-----------------------------------------------------------------------------------------------
VOID
DokanPrintNTStatus(
	NTSTATUS	Status)
{
	PrintStatus(Status, STATUS_SUCCESS);
	PrintStatus(Status, STATUS_NO_MORE_FILES);
	PrintStatus(Status, STATUS_END_OF_FILE);
	PrintStatus(Status, STATUS_NO_SUCH_FILE);
	PrintStatus(Status, STATUS_NOT_IMPLEMENTED);
	PrintStatus(Status, STATUS_BUFFER_OVERFLOW);
	PrintStatus(Status, STATUS_FILE_IS_A_DIRECTORY);
	PrintStatus(Status, STATUS_SHARING_VIOLATION);
	PrintStatus(Status, STATUS_OBJECT_NAME_INVALID);
	PrintStatus(Status, STATUS_OBJECT_NAME_NOT_FOUND);
	PrintStatus(Status, STATUS_OBJECT_NAME_COLLISION);
	PrintStatus(Status, STATUS_OBJECT_PATH_INVALID);
	PrintStatus(Status, STATUS_OBJECT_PATH_NOT_FOUND);
	PrintStatus(Status, STATUS_OBJECT_PATH_SYNTAX_BAD);
	PrintStatus(Status, STATUS_ACCESS_DENIED);
	PrintStatus(Status, STATUS_ACCESS_VIOLATION);
	PrintStatus(Status, STATUS_INVALID_PARAMETER);
	PrintStatus(Status, STATUS_INVALID_USER_BUFFER);
	PrintStatus(Status, STATUS_INVALID_HANDLE);
}

//-----------------------------------------------------------------------------------------------
//--- DokanNotifyReportChange0
//-----------------------------------------------------------------------------------------------
VOID
DokanNotifyReportChange0(
	__in PDokanFCB			Fcb,
	__in PUNICODE_STRING	FileName,
	__in ULONG				FilterMatch,
	__in ULONG				Action)
{
	USHORT	nameOffset;
	DDBGPRINT("[RCloudFS] DokanNotifyReportChange() : ...Start");
	DDBGPRINT("[RCloudFS] DokanNotifyReportChange() : ...FileName=[%wZ]", FileName);

	ASSERT(Fcb != NULL);
	ASSERT(FileName != NULL);

	// search the last "\"
	nameOffset = (USHORT)(FileName->Length/sizeof(WCHAR)-1);
	for(; FileName->Buffer[nameOffset] != L'\\'; --nameOffset)
	{
	}

	nameOffset++; // the next is the begining of filename

	nameOffset *= sizeof(WCHAR); // Offset is in bytes

	FsRtlNotifyFullReportChange(
		Fcb->Vcb->NotifySync,
		&Fcb->Vcb->DirNotifyList,
		(PSTRING)FileName,
		nameOffset,
		NULL, // StreamName
		NULL, // NormalizedParentName
		FilterMatch,
		Action,
		NULL); // TargetContext

	DDBGPRINT("[RCloudFS] DokanNotifyReportChange() : ...End");
}

//-----------------------------------------------------------------------------------------------
//--- DokanNotifyReportChange
//-----------------------------------------------------------------------------------------------
VOID
DokanNotifyReportChange(
	__in PDokanFCB	Fcb,
	__in ULONG		FilterMatch,
	__in ULONG		Action)
{
	ASSERT(Fcb != NULL);
	DokanNotifyReportChange0(Fcb, &Fcb->FileName, FilterMatch, Action);
}

//-----------------------------------------------------------------------------------------------
//--- PrintIdType
//-----------------------------------------------------------------------------------------------
VOID
PrintIdType(
	__in VOID* Id)
{
	if (Id == NULL) 
	{
		DDBGPRINT("[RCloudFS] PrintIdType() : ...IdType = NULL");
		
		return;
	}
	switch (GetIdentifierType(Id)) 
	{
		case DGL:
			DDBGPRINT("[RCloudFS] PrintIdType() : GetIdentifierType()...IdType = DGL");
			break;

		case DCB:
			DDBGPRINT("[RCloudFS] PrintIdType() : GetIdentifierType()...IdType = DCB");
			break;

		case VCB:
			DDBGPRINT("[RCloudFS] PrintIdType() : GetIdentifierType()...IdType = VCB");
			break;

		case FCB:
			DDBGPRINT("[RCloudFS] PrintIdType() : GetIdentifierType()...IdType = FCB");
			break;

		case CCB:
			DDBGPRINT("[RCloudFS] PrintIdType() : GetIdentifierType()...IdType = CCB");
			break;

		default:
			DDBGPRINT("[RCloudFS] PrintIdType() : GetIdentifierType()...IdType = Unknown");
			break;
	}
}

//-----------------------------------------------------------------------------------------------
//--- DokanCheckCCB
//-----------------------------------------------------------------------------------------------
BOOLEAN
DokanCheckCCB(
	__in PDokanDCB	Dcb,
	__in PDokanCCB	Ccb)
{
	ASSERT(Dcb != NULL);

	if (GetIdentifierType(Dcb) != DCB) 
	{
		PrintIdType(Dcb);
		
		return FALSE;
	}

	if (Ccb == NULL) 
	{
		PrintIdType(Dcb);
		DDBGPRINT("[RCloudFS] DokanCheckCCB() : PrintIdType()...Ccb is NULL");
		
		return FALSE;
	}

	if (Ccb->MountId != Dcb->MountId) 
	{
		DDBGPRINT("[RCloudFS] DokanCheckCCB() : ...MountId is different");
		
		return FALSE;
	}

	if (!Dcb->Mounted)
	{
		DDBGPRINT("[RCloudFS] DokanCheckCCB() : ...Not mounted");
		
		return FALSE;
	}

	return TRUE;
}

//-----------------------------------------------------------------------------------------------
//--- DokanAllocateMdl
//-----------------------------------------------------------------------------------------------
NTSTATUS
DokanAllocateMdl(
	__in PIRP	Irp,
	__in ULONG	Length)
{
	if (Irp->MdlAddress == NULL) 
	{
		Irp->MdlAddress = IoAllocateMdl(Irp->UserBuffer, Length, FALSE, FALSE, Irp);

		if (Irp->MdlAddress == NULL) 
		{
			DDBGPRINT("[RCloudFS] DokanAllocateMdl() : IoAllocateMdl()...returned NULL");
			
			return STATUS_INSUFFICIENT_RESOURCES;
		}
		__try 
		{
			MmProbeAndLockPages(Irp->MdlAddress, Irp->RequestorMode, IoWriteAccess);
		} 
		__except (EXCEPTION_EXECUTE_HANDLER) 
		{
			DDBGPRINT("[RCloudFS] DokanAllocateMdl() : MmProveAndLockPages()...Error");
			IoFreeMdl(Irp->MdlAddress);
			Irp->MdlAddress = NULL;

			return STATUS_INSUFFICIENT_RESOURCES;
		}
	}

	return STATUS_SUCCESS;
}

//-----------------------------------------------------------------------------------------------
//--- DokanFreeMdl
//-----------------------------------------------------------------------------------------------
VOID
DokanFreeMdl(
	__in PIRP	Irp)
{
	if (Irp->MdlAddress != NULL) 
	{
		MmUnlockPages(Irp->MdlAddress);
		IoFreeMdl(Irp->MdlAddress);
		Irp->MdlAddress = NULL;
	}
}

//-----------------------------------------------------------------------------------------------