/*
  Dokan : user-mode file system library for Windows

  Copyright (C) 2008 Hiroki Asakawa info@dokan-dev.net

  http://dokan-dev.net/en

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the Free
Software Foundation; either version 3 of the License, or (at your option) any
later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU Lesser General Public License along
with this program. If not, see <http://www.gnu.org/licenses/>.
*/

//-----------------------------------------------------------------------------------------------
#include "dokan.h"

NTSTATUS
DokanQueryDirectory(
	__in PDEVICE_OBJECT DeviceObject,
	__in PIRP			Irp);

NTSTATUS
DokanNotifyChangeDirectory(
	__in PDEVICE_OBJECT DeviceObject,
	__in PIRP			Irp);

//-----------------------------------------------------------------------------------------------
//--- DokanDispatchDirectoryControl
//-----------------------------------------------------------------------------------------------
NTSTATUS
DokanDispatchDirectoryControl(
	__in PDEVICE_OBJECT DeviceObject,
	__in PIRP Irp)
{
	NTSTATUS			status		= STATUS_NOT_IMPLEMENTED;
	PFILE_OBJECT		fileObject;
	PIO_STACK_LOCATION	irpSp;
	PDokanCCB			ccb;
	PDokanVCB			vcb;

	PAGED_CODE();

	__try 
	{
		FsRtlEnterFileSystem();

		DDBGPRINT("[RCloudFS] DokanDispatchDirectoryControl() : ...Start");

		irpSp		= IoGetCurrentIrpStackLocation(Irp);
		fileObject	= irpSp->FileObject;
		DDBGPRINT("[RCloudFS] DokanDispatchDirectoryControl() : IoGetCurrentIrpStackLocation()...fileObject=[%X]", fileObject);

		if (fileObject == NULL) 
		{
			status = STATUS_INVALID_PARAMETER;
			
			__leave;
		}

		vcb = DeviceObject->DeviceExtension;

		if (GetIdentifierType(vcb) != VCB || !DokanCheckCCB(vcb->Dcb, fileObject->FsContext2)) 
		{
			status = STATUS_INVALID_PARAMETER;
			
			__leave;
		}

		DDBGPRINT("[RCloudFS] DokanDispatchDirectoryControl() : IoGetRequestorProcessId()...ProcessId=[%lu]", IoGetRequestorProcessId(Irp));
		DokanPrintFileName(fileObject);

		if (irpSp->MinorFunction == IRP_MN_QUERY_DIRECTORY) 
		{
			status = DokanQueryDirectory(DeviceObject, Irp);
			DDBGPRINT("[RCloudFS] DokanDispatchDirectoryControl() : DokanQueryDirectory()...status=[%X]", status);
	
		} 
		else if( irpSp->MinorFunction == IRP_MN_NOTIFY_CHANGE_DIRECTORY) 
		{
			status = DokanNotifyChangeDirectory(DeviceObject, Irp);
			DDBGPRINT("[RCloudFS] DokanDispatchDirectoryControl() : DokanNotifyChangeDirectory()...status=[%X]", status);
		} 
		else 
		{
			DDBGPRINT("[RCloudFS] DokanDispatchDirectoryControl() : ...invalid minor function");
			status = STATUS_INVALID_PARAMETER;
		}
	
	} 
	__finally 
	{

		if (status != STATUS_PENDING) 
		{
			Irp->IoStatus.Status = status;
			Irp->IoStatus.Information = 0;
			IoCompleteRequest(Irp, IO_NO_INCREMENT);
		}

		DokanPrintNTStatus(status);
		DDBGPRINT("[RCloudFS] DokanDispatchDirectoryControl() : ...End");

		FsRtlExitFileSystem();
	}

	return status;
}

//-----------------------------------------------------------------------------------------------
//--- DokanQueryDirectory
//-----------------------------------------------------------------------------------------------
NTSTATUS
DokanQueryDirectory(
	__in PDEVICE_OBJECT DeviceObject,
	__in PIRP			Irp)
{
	PFILE_OBJECT		fileObject;
	PIO_STACK_LOCATION	irpSp;
	PDokanVCB			vcb;
	PDokanCCB			ccb;
	PDokanFCB			fcb;
	NTSTATUS			status;
	PUNICODE_STRING		searchPattern;
	ULONG				eventLength;
	PEVENT_CONTEXT		eventContext;
	ULONG				index;
	BOOLEAN				initial;
	ULONG				flags = 0;

	irpSp		= IoGetCurrentIrpStackLocation(Irp);
	fileObject	= irpSp->FileObject;

	vcb = DeviceObject->DeviceExtension;
	if (GetIdentifierType(vcb) != VCB) 
	{
		return STATUS_INVALID_PARAMETER;
	}

	ccb = fileObject->FsContext2;
	if (ccb == NULL) 
	{
		return STATUS_INVALID_PARAMETER;
	}
	ASSERT(ccb != NULL);

	fcb = ccb->Fcb;
	ASSERT(fcb != NULL);

	if (irpSp->Flags & SL_INDEX_SPECIFIED) 
	{
		DDBGPRINT("[RCloudFS] DokanQueryDirectory() : IoGetCurrentIrpStackLocation()...FileIndex=[%d]", irpSp->Parameters.QueryDirectory.FileIndex);
	}
	
	if (irpSp->Flags & SL_RETURN_SINGLE_ENTRY) 
	{
		DDBGPRINT("[RCloudFS] DokanQueryDirectory() : IoGetCurrentIrpStackLocation()...Return Single Entry");
	}
	
	if (irpSp->Flags & SL_RESTART_SCAN) 
	{
		DDBGPRINT("[RCloudFS] DokanQueryDirectory() : IoGetCurrentIrpStackLocation()...restart scan");
	}
	
	if (irpSp->Parameters.QueryDirectory.FileName) 
	{
		DDBGPRINT("[RCloudFS] DokanQueryDirectory() : IoGetCurrentIrpStackLocation()...pattern=[%wZ]", irpSp->Parameters.QueryDirectory.FileName);
	}
	
	switch (irpSp->Parameters.QueryDirectory.FileInformationClass) 
	{
		case FileDirectoryInformation:
			DDBGPRINT("[RCloudFS] DokanQueryDirectory() : ...FileDirectoryInformation");
			break;
		
		case FileFullDirectoryInformation:
			DDBGPRINT("[RCloudFS] DokanQueryDirectory() : ...FileFullDirectoryInformation");
			break;
		
		case FileNamesInformation:
			DDBGPRINT("[RCloudFS] DokanQueryDirectory() : ...FileNamesInformation");
			break;
		
		case FileBothDirectoryInformation:
			DDBGPRINT("[RCloudFS] DokanQueryDirectory() : ...FileBothDirectoryInformation");
			break;
		
		case FileIdBothDirectoryInformation:
			DDBGPRINT("[RCloudFS] DokanQueryDirectory() : ...FileIdBothDirectoryInformation");
			break;
		
		default:
			DDBGPRINT("[RCloudFS] DokanQueryDirectory() : ...FileInformationClass=[%d]", irpSp->Parameters.QueryDirectory.FileInformationClass);
			break;
	}

	// make a MDL for UserBuffer that can be used later on another thread context
	if (Irp->MdlAddress == NULL) 
	{
		status = DokanAllocateMdl(Irp, irpSp->Parameters.QueryDirectory.Length);
		if (!NT_SUCCESS(status)) 
		{
			return status;
		}

		flags = DOKAN_MDL_ALLOCATED;
	}

	
	// size of EVENT_CONTEXT is sum of its length and file name length
	eventLength = sizeof(EVENT_CONTEXT) + fcb->FileName.Length;

	initial = (BOOLEAN)(ccb->SearchPattern == NULL && !(ccb->Flags & DOKAN_DIR_MATCH_ALL));

	// this is an initial query
	if (initial) 
	{
		DDBGPRINT("[RCloudFS] DokanQueryDirectory() : ...initial query");
		// and search pattern is provided
		if (irpSp->Parameters.QueryDirectory.FileName) 
		{
			// free current search pattern stored in CCB
			if (ccb->SearchPattern)
			{
				ExFreePool(ccb->SearchPattern);
			}

			// the size of search pattern
			ccb->SearchPatternLength = irpSp->Parameters.QueryDirectory.FileName->Length;
			ccb->SearchPattern = ExAllocatePool(ccb->SearchPatternLength + sizeof(WCHAR));

			if (ccb->SearchPattern == NULL) 
			{
				return STATUS_INSUFFICIENT_RESOURCES;
			}

			RtlZeroMemory(ccb->SearchPattern, ccb->SearchPatternLength + sizeof(WCHAR));

			// copy provided search pattern to CCB
			RtlCopyMemory(ccb->SearchPattern, irpSp->Parameters.QueryDirectory.FileName->Buffer, ccb->SearchPatternLength);
		} 
		else 
		{
			ccb->Flags |= DOKAN_DIR_MATCH_ALL;
		}
	}

	// if search pattern is provided, add the length of it to store pattern
	if (ccb->SearchPattern) 
	{
		eventLength += ccb->SearchPatternLength;
	}
		
	eventContext = AllocateEventContext(vcb->Dcb, Irp, eventLength, ccb);

	if (eventContext == NULL) 
	{
		return STATUS_INSUFFICIENT_RESOURCES;
	}

	eventContext->Context = ccb->UserContext;
	//DDBGPRINT("[RCloudFS]    get Context %X\n", (ULONG)ccb->UserContext);

	// index which specified index-1 th directory entry has been returned
	// this time, 'index'th entry should be returned
	index = 0;

	if (irpSp->Flags & SL_INDEX_SPECIFIED) 
	{
		index = irpSp->Parameters.QueryDirectory.FileIndex;
		DDBGPRINT("[RCloudFS] DokanQueryDirectory() : ...index=[%d]", index);
		
	} 
	else if (FlagOn(irpSp->Flags, SL_RESTART_SCAN))
	{
		DDBGPRINT("[RCloudFS] DokanQueryDirectory() : ...SL_RESTART_SCAN");
		index = 0;
		
	}
	else 
	{
		index = (ULONG)ccb->Context;
		DDBGPRINT("[RCloudFS] DokanQueryDirectory() : ...index=[%d]", index);
	}

	eventContext->Directory.FileInformationClass	= irpSp->Parameters.QueryDirectory.FileInformationClass;
	eventContext->Directory.BufferLength			= irpSp->Parameters.QueryDirectory.Length; // length of buffer
	eventContext->Directory.FileIndex				= index; // directory index which should be returned this time

	// copying file name(directory name)
	eventContext->Directory.DirectoryNameLength = fcb->FileName.Length;
	RtlCopyMemory(eventContext->Directory.DirectoryName, fcb->FileName.Buffer, fcb->FileName.Length);

	// if search pattern is specified, copy it to EventContext
	if (ccb->SearchPatternLength) 
	{
		PVOID searchBuffer;

		eventContext->Directory.SearchPatternLength = ccb->SearchPatternLength;
		eventContext->Directory.SearchPatternOffset = eventContext->Directory.DirectoryNameLength;
			
		searchBuffer = (PVOID)((SIZE_T) &eventContext->Directory.SearchPatternBase[0] + (SIZE_T) eventContext->Directory.SearchPatternOffset);
			
		RtlCopyMemory(searchBuffer, 
						ccb->SearchPattern,
						ccb->SearchPatternLength);

		DDBGPRINT("[RCloudFS] DokanQueryDirectory() : ...SearchPattern=[%ws]", ccb->SearchPattern);
	}


	status = DokanRegisterPendingIrp(DeviceObject, Irp, eventContext, flags);

	return status;
}

//-----------------------------------------------------------------------------------------------
//--- DokanNotifyChangeDirectory
//-----------------------------------------------------------------------------------------------
NTSTATUS
DokanNotifyChangeDirectory(
	__in PDEVICE_OBJECT DeviceObject,
	__in PIRP			Irp)
{
	PDokanCCB			ccb;
	PDokanFCB			fcb;
	PFILE_OBJECT		fileObject;
	PIO_STACK_LOCATION	irpSp;
	PDokanVCB			vcb;

	DDBGPRINT("[RCloudFS] DokanNotifyChangeDirectory() : ...");

	irpSp		= IoGetCurrentIrpStackLocation(Irp);
	fileObject	= irpSp->FileObject;

	vcb = DeviceObject->DeviceExtension;
	if (GetIdentifierType(vcb) != VCB) 
	{
		return STATUS_INVALID_PARAMETER;
	}
	
	ccb = fileObject->FsContext2;
	ASSERT(ccb != NULL);

	fcb = ccb->Fcb;
	ASSERT(fcb != NULL);

	if (!(fcb->Flags & DOKAN_FILE_DIRECTORY))
	{
		return STATUS_INVALID_PARAMETER;
	}

	FsRtlNotifyFullChangeDirectory(
		vcb->NotifySync,
		&vcb->DirNotifyList,
		ccb,
		(PSTRING)&fcb->FileName,
		irpSp->Flags & SL_WATCH_TREE ? TRUE : FALSE,
		FALSE,
		irpSp->Parameters.NotifyDirectory.CompletionFilter,
		Irp,
		NULL,
		NULL);

	return STATUS_PENDING;
}

//-----------------------------------------------------------------------------------------------
//--- DokanCompleteDirectoryControl
//-----------------------------------------------------------------------------------------------
VOID
DokanCompleteDirectoryControl(
	__in PIRP_ENTRY			IrpEntry,
	__in PEVENT_INFORMATION	EventInfo)
{
	PIRP				irp;
	PIO_STACK_LOCATION	irpSp;
	NTSTATUS			status   = STATUS_SUCCESS;
	ULONG				info	 = 0;
	ULONG				bufferLen= 0;
	PVOID				buffer	 = NULL;

	//FsRtlEnterFileSystem();

	DDBGPRINT("[RCloudFS] DokanCompleteDirectoryControl() : ...Start");

	irp   = IrpEntry->Irp;
	irpSp = IrpEntry->IrpSp;	


	// buffer pointer which points DirecotryInfo
	if (irp->MdlAddress)
	{
		//DDBGPRINT("[RCloudFS]    use MDL Address");
		buffer = MmGetSystemAddressForMdlSafe(irp->MdlAddress, NormalPagePriority);
	} 
	else 
	{
		//DDBGPRINT("[RCloudFS]    use UserBuffer");
		buffer	= irp->UserBuffer;
	}
	// usable buffer size
	bufferLen = irpSp->Parameters.QueryDirectory.Length;

	//DDBGPRINT("[RCloudFS]   !!Returning DirecotyInfo!!");

	// buffer is not specified or short of length
	if (bufferLen == 0 || buffer == NULL || bufferLen < EventInfo->BufferLength) 
	{
		info   = 0;
		status = STATUS_INSUFFICIENT_RESOURCES;
	} 
	else 
	{
		PDokanCCB ccb	= IrpEntry->FileObject->FsContext2;
		ULONG	 orgLen = irpSp->Parameters.QueryDirectory.Length;

		//
		// set the information recieved from user mode
		//
		ASSERT(buffer != NULL);
		
		RtlZeroMemory(buffer, bufferLen);
		
		//DDBGPRINT("[RCloudFS]    copy DirectoryInfo");
		RtlCopyMemory(buffer, EventInfo->Buffer, EventInfo->BufferLength);

		DDBGPRINT("[RCloudFS] DokanCompleteDirectoryControl() : ...eventInfo->Directory.Index=[%d]", EventInfo->Directory.Index);
		DDBGPRINT("[RCloudFS] DokanCompleteDirectoryControl() : ...eventInfo->BufferLength=[%d]", EventInfo->BufferLength);
		DDBGPRINT("[RCloudFS] DokanCompleteDirectoryControl() : ...eventInfo->Status=[%x (%d)]", EventInfo->Status, EventInfo->Status);

		// update index which specified n-th directory entry is returned
		// this should be locked before writing?
		ccb->Context = EventInfo->Directory.Index;

		ccb->UserContext = EventInfo->Context;
		//DDBGPRINT("[RCloudFS] DokanCompleteDirectoryControl() : ...set Context %X\n", (ULONG)ccb->UserContext);

		// written bytes
		//irpSp->Parameters.QueryDirectory.Length = EventInfo->BufferLength;

		status = EventInfo->Status;
		
		info = EventInfo->BufferLength;
	}

	if (IrpEntry->Flags & DOKAN_MDL_ALLOCATED) 
	{
		DokanFreeMdl(irp);
		IrpEntry->Flags &= ~DOKAN_MDL_ALLOCATED;
	}

	irp->IoStatus.Status = status;
	irp->IoStatus.Information = info;
	IoCompleteRequest(irp, IO_NO_INCREMENT);

	DokanPrintNTStatus(status);

	DDBGPRINT("[RCloudFS] DokanCompleteDirectoryControl() : ...End");

	//FsRtlExitFileSystem();
}

//-----------------------------------------------------------------------------------------------

